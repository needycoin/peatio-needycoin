module Peatio
  module Needycoin
    VERSION = "0.1.1".freeze
  end
end
